"use client"

import { useEffect, useRef, useState } from "react"
import { useRouter } from "next/navigation"
import { X, Airplay, Subtitles, SkipBack, Play, Pause, SkipForward, Maximize } from "lucide-react"
import { Slider } from "@/components/ui/slider"
import { getContentDetail } from "@/lib/api"
import { useQuery } from "@tanstack/react-query"

export default function WatchContent({ params }: { params: { id: string } }) {
  const router = useRouter()
  const videoRef = useRef<HTMLVideoElement>(null)
  const [isPlaying, setIsPlaying] = useState(false)
  const [currentTime, setCurrentTime] = useState(0)
  const [duration, setDuration] = useState(0)
  const [showControls, setShowControls] = useState(true)
  const controlsTimeoutRef = useRef<NodeJS.Timeout | null>(null)

  const { data: content, isLoading } = useQuery({
    queryKey: ["content", params.id],
    queryFn: () => getContentDetail(params.id),
  })

  useEffect(() => {
    const video = videoRef.current
    if (!video) return

    const handleTimeUpdate = () => {
      setCurrentTime(video.currentTime)
    }

    const handleLoadedMetadata = () => {
      setDuration(video.duration)
    }

    const handlePlay = () => setIsPlaying(true)
    const handlePause = () => setIsPlaying(false)

    video.addEventListener("timeupdate", handleTimeUpdate)
    video.addEventListener("loadedmetadata", handleLoadedMetadata)
    video.addEventListener("play", handlePlay)
    video.addEventListener("pause", handlePause)

    return () => {
      video.removeEventListener("timeupdate", handleTimeUpdate)
      video.removeEventListener("loadedmetadata", handleLoadedMetadata)
      video.removeEventListener("play", handlePlay)
      video.removeEventListener("pause", handlePause)
    }
  }, [])

  useEffect(() => {
    const handleUserActivity = () => {
      setShowControls(true)

      if (controlsTimeoutRef.current) {
        clearTimeout(controlsTimeoutRef.current)
      }

      controlsTimeoutRef.current = setTimeout(() => {
        if (isPlaying) {
          setShowControls(false)
        }
      }, 3000)
    }

    window.addEventListener("mousemove", handleUserActivity)
    window.addEventListener("touchstart", handleUserActivity)

    return () => {
      window.removeEventListener("mousemove", handleUserActivity)
      window.removeEventListener("touchstart", handleUserActivity)

      if (controlsTimeoutRef.current) {
        clearTimeout(controlsTimeoutRef.current)
      }
    }
  }, [isPlaying])

  const togglePlayPause = () => {
    const video = videoRef.current
    if (!video) return

    if (video.paused) {
      video.play()
    } else {
      video.pause()
    }
  }

  const handleSeek = (value: number[]) => {
    const video = videoRef.current
    if (!video) return

    video.currentTime = value[0]
    setCurrentTime(value[0])
  }

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60)
    const secs = Math.floor(seconds % 60)
    return `${mins}:${secs < 10 ? "0" : ""}${secs}`
  }

  const skipForward = () => {
    const video = videoRef.current
    if (!video) return

    video.currentTime = Math.min(video.currentTime + 15, video.duration)
  }

  const skipBackward = () => {
    const video = videoRef.current
    if (!video) return

    video.currentTime = Math.max(video.currentTime - 15, 0)
  }

  const handleFullscreen = () => {
    const videoContainer = document.documentElement

    if (document.fullscreenElement) {
      document.exitFullscreen()
    } else {
      videoContainer.requestFullscreen()
    }
  }

  const handleClose = () => {
    router.back()
  }

  if (isLoading) {
    return (
      <div className="fixed inset-0 bg-black flex items-center justify-center">
        <div className="animate-spin w-12 h-12 border-t-2 border-blue-500 border-r-2 rounded-full"></div>
      </div>
    )
  }

  return (
    <div className="fixed inset-0 bg-black">
      <video
        ref={videoRef}
        className="w-full h-full object-contain"
        src={content?.video_url || "/placeholder-video.mp4"}
        onClick={togglePlayPause}
        autoPlay
      />

      {showControls && (
        <>
          <div className="absolute top-4 left-0 right-0 flex justify-between items-center px-4">
            <button onClick={handleClose} className="bg-black/50 p-2 rounded-full">
              <X size={20} />
            </button>

            <div className="flex gap-2">
              <button className="bg-black/50 p-2 rounded-full">
                <Airplay size={20} />
              </button>
              <button className="bg-black/50 p-2 rounded-full">
                <Subtitles size={20} />
              </button>
            </div>
          </div>

          <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/80 to-transparent p-4">
            <div className="flex items-center gap-2 mb-2">
              <span className="text-sm">{formatTime(currentTime)}</span>
              <Slider
                value={[currentTime]}
                min={0}
                max={duration || 100}
                step={1}
                onValueChange={handleSeek}
                className="flex-1"
              />
              <span className="text-sm">-{formatTime(duration - currentTime)}</span>
            </div>

            <div className="flex justify-between items-center">
              <div className="flex items-center gap-4">
                <button onClick={skipBackward} className="p-2">
                  <SkipBack size={24} />
                </button>
                <button onClick={togglePlayPause} className="p-2">
                  {isPlaying ? <Pause size={28} /> : <Play size={28} />}
                </button>
                <button onClick={skipForward} className="p-2">
                  <SkipForward size={24} />
                </button>
              </div>

              <button onClick={handleFullscreen} className="p-2">
                <Maximize size={24} />
              </button>
            </div>
          </div>
        </>
      )}
    </div>
  )
}


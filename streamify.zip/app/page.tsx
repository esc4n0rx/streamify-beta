import { Suspense } from "react"
import Avatar from "@/components/Avatar"
import ContentRow from "@/components/ContentRow"
import ContentRowSkeleton from "@/components/skeletons/ContentRowSkeleton"
import { getTrending, getContinueWatching, getRecommendations } from "@/lib/api"

export default async function Home() {
  return (
    <div className="pb-20">
      <div className="flex justify-between items-center p-4 pt-6">
        <h1 className="text-3xl font-bold">Watch Now</h1>
        <Avatar />
      </div>

      <div className="px-4 py-2">
        <div className="inline-block bg-zinc-800 rounded-full px-4 py-1.5">
          <span className="flex items-center gap-2">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="16"
              height="16"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
              className="lucide lucide-film"
            >
              <rect width="18" height="18" x="3" y="3" rx="2" />
              <path d="M7 3v18" />
              <path d="M3 7.5h4" />
              <path d="M3 12h18" />
              <path d="M3 16.5h4" />
              <path d="M17 3v18" />
              <path d="M17 7.5h4" />
              <path d="M17 16.5h4" />
            </svg>
            MOVIES
          </span>
        </div>
      </div>

      <section className="mt-6">
        <h2 className="text-2xl font-semibold px-4 mb-3">Up Next</h2>
        <Suspense fallback={<ContentRowSkeleton />}>
          <TrendingContent />
        </Suspense>
      </section>

      <section className="mt-8">
        <h2 className="text-2xl font-semibold px-4 mb-3">Continue Watching</h2>
        <Suspense fallback={<ContentRowSkeleton />}>
          <ContinueWatchingContent />
        </Suspense>
      </section>

      <section className="mt-8">
        <div className="flex justify-between items-center px-4 mb-3">
          <h2 className="text-2xl font-semibold">Want to Watch</h2>
          <a href="#" className="text-blue-500">
            See All
          </a>
        </div>
        <Suspense fallback={<ContentRowSkeleton />}>
          <RecommendedContent />
        </Suspense>
      </section>
    </div>
  )
}

async function TrendingContent() {
  const trending = await getTrending()
  // Garantir que trending seja um array
  return <ContentRow contents={Array.isArray(trending) ? trending : []} aspectRatio="landscape" />
}

async function ContinueWatchingContent() {
  const continueWatching = await getContinueWatching()
  // Garantir que continueWatching seja um array
  const safeData = Array.isArray(continueWatching) ? continueWatching : []

  if (safeData.length === 0) {
    return (
      <div className="px-4 py-8 text-center text-gray-400">
        <p>You haven't watched anything yet</p>
      </div>
    )
  }

  return <ContentRow contents={safeData} aspectRatio="landscape" />
}

async function RecommendedContent() {
  const recommendations = await getRecommendations()
  // Garantir que recommendations seja um array
  return <ContentRow contents={Array.isArray(recommendations) ? recommendations : []} aspectRatio="portrait" />
}


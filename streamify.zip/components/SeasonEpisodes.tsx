"use client"

import { useState } from "react"
import Image from "next/image"
import Link from "next/link"
import { ChevronDown, ChevronUp, Download, Play } from "lucide-react"
import { motion, AnimatePresence } from "framer-motion"

type Episode = {
  id: string
  title: string
  episode_number: number
  duration: number
  thumbnail_url: string
  description?: string
  is_downloaded?: boolean
}

type Season = {
  id: string
  season_number: number
  episodes: Episode[]
}

type SeasonEpisodesProps = {
  season: Season
}

export default function SeasonEpisodes({ season }: SeasonEpisodesProps) {
  const [isExpanded, setIsExpanded] = useState(season.season_number === 1)

  return (
    <div className="mb-6">
      <button
        className="flex items-center justify-between w-full py-2 text-left"
        onClick={() => setIsExpanded(!isExpanded)}
      >
        <h3 className="text-xl font-semibold">Season {season.season_number}</h3>
        {isExpanded ? <ChevronUp size={20} /> : <ChevronDown size={20} />}
      </button>

      <AnimatePresence>
        {isExpanded && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.3 }}
            className="overflow-hidden"
          >
            <div className="space-y-4 mt-2">
              {season.episodes.map((episode) => (
                <div key={episode.id} className="flex border-b border-zinc-800 pb-4">
                  <div className="w-24 h-16 relative flex-shrink-0">
                    <Image
                      src={episode.thumbnail_url || "/placeholder.svg?height=200&width=300"}
                      alt={episode.title}
                      fill
                      className="object-cover rounded"
                    />
                  </div>

                  <div className="ml-3 flex-grow">
                    <div className="flex justify-between">
                      <h4 className="font-medium">{episode.title}</h4>
                      <div className="flex items-center">
                        {episode.is_downloaded ? (
                          <div className="text-blue-500">
                            <Download size={18} />
                          </div>
                        ) : (
                          <button className="text-gray-400 hover:text-blue-500">
                            <Download size={18} />
                          </button>
                        )}
                      </div>
                    </div>
                    <div className="text-sm text-gray-400">
                      EP {episode.episode_number} • {episode.duration} min
                    </div>
                  </div>

                  <Link href={`/assistir/${episode.id}`} className="ml-2 self-center">
                    <Play size={20} />
                  </Link>
                </div>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  )
}


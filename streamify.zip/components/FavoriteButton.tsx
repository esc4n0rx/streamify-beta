"use client"

import type React from "react"

import { Heart } from "lucide-react"
import { Button } from "@/components/ui/button"
import { useFavoritesStore } from "@/store/favoritesStore"
import { useState } from "react"
import { useToast } from "@/components/ui/use-toast"

type FavoriteButtonProps = {
  contentId: string
  size?: "sm" | "md" | "lg"
  variant?: "icon" | "default"
}

export default function FavoriteButton({ contentId, size = "md", variant = "icon" }: FavoriteButtonProps) {
  const { isFavorite, toggleFavorite } = useFavoritesStore()
  const [isLoading, setIsLoading] = useState(false)
  const { toast } = useToast()
  const isFav = isFavorite(contentId)

  const handleToggleFavorite = async (e: React.MouseEvent) => {
    e.preventDefault()
    e.stopPropagation()

    setIsLoading(true)

    try {
      await toggleFavorite({
        id: contentId,
        title: "",
        poster_url: "",
      })

      toast({
        title: isFav ? "Removido dos favoritos" : "Adicionado aos favoritos",
        duration: 2000,
      })
    } catch (error) {
      toast({
        title: "Erro",
        description: "Não foi possível atualizar os favoritos",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  const sizeClasses = {
    sm: "w-8 h-8",
    md: "w-10 h-10",
    lg: "w-12 h-12",
  }

  if (variant === "icon") {
    return (
      <Button
        variant="ghost"
        size="icon"
        className={`${sizeClasses[size]} rounded-full bg-black/50 backdrop-blur-sm ${
          isFav ? "text-red-500" : "text-white"
        }`}
        onClick={handleToggleFavorite}
        disabled={isLoading}
      >
        <Heart className={`${isFav ? "fill-current" : ""}`} size={size === "sm" ? 16 : 20} />
      </Button>
    )
  }

  return (
    <Button
      variant="outline"
      className={`${isFav ? "text-red-500" : "text-white"}`}
      onClick={handleToggleFavorite}
      disabled={isLoading}
    >
      <Heart className={`mr-2 ${isFav ? "fill-current" : ""}`} size={16} />
      {isFav ? "Remover dos favoritos" : "Adicionar aos favoritos"}
    </Button>
  )
}

